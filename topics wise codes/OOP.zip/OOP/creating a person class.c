class Person{

    public Person()
    {
        name="Shohan";
        birthdayYear=1995;

    }


    public Person(String givenName , int yearOfBirth)
    {
        name= givenName;
        birthdayYear= yearOfBirth;
    }

    public String getName()
    {
        return name;
    }

     public int getYear()
    {
        return birthdayYear;
    }

    public String changeName(String namex)
    {
        name=namex;
        return name;
    }

       public int getAgeInYears(int currentYear)
    {
        return currentYear-birthdayYear;

    }

    private String name;
    private int birthdayYear;
}

class x
{
   public static void main(String[] args)
    {
        Person unknown= new Person();
        System.out.println("My name is "+unknown.getName());
         System.out.println("My birthyear is "+unknown.getYear());
          System.out.println("My age is "+unknown.getAgeInYears(2016));

		Person known = new Person("Palas",1997);
        System.out.println("Your name is "+known.getName());
        System.out.println("Your birthyear is "+known.getYear());
         System.out.println("Your age is "+ unknown.getAgeInYears(2016));


         System.out.println("Shohan is changed to "+unknown.changeName("Amit"));

    }


}
