class Account{

    public Account()
    {
        balance=0;
    }

    public Account(int x)
    {
        balance=x;
    }

    public int add(int money)
    {
        balance+=money;
        return balance;
    }

    public int attempt(int money)
    {
        if(balance-money<0) return 1;
        else return 0;
    }

    public int withdraw(int money)
    {
        if(attempt(money)==1)  { System.out.println("You are charged ");  balance-=5;   }
        else
        balance-=money;

        return balance;
    }

    public int inquire()
    {
        return balance;
    }

    public int inter()
    {
        return balance*5/100;
    }


    private int balance;
    private int interest;

}

class x
{
    public static void main(String[] args)
    {
        Account a= new Account();
        Account b= new Account(500);

        System.out.println(a.inquire()+" "+a.inter());
        System.out.println(b.inquire()+" "+b.inter());

         System.out.println(a.add(8));
         System.out.println(a.withdraw(10));
    }


}

