class Address{

    public Address()
    {
        house_number=47;
        street="Hazi_Afsar_Uddin_Lane";
        city="Dhaka";
        country="Bangladesh";
        postal_code=1278;
    }

    public Address(int apart_no)
    {
        house_number=47;
        street="Hazi_Afsar_Uddin_Lane";
        apartment_number=apart_no;
        city="Dhaka";
        country="Bangladesh";
        postal_code=1278;
    }

    public void get_house(int housex){
        house_number=housex;  }
    public void get_street(String streetx) {
        street=streetx;}
    public void get_apa(int apart) {
        apartment_number=apart;}
    public void get_city(String cit) {
        city=cit;}
    public void get_country(String coun) {
        country=coun; }
    public void get_code(int x) {
        postal_code=x; }

    public void print()
    {
        System.out.println(apartment_number+" "+house_number+" "+street);
        System.out.println(postal_code+" "+city+" "+country);
    }


    public void compareTo(Address x, Address y)
    {
        if(x.postal_code>y.postal_code) {x.print();  y.print(); }
        else { y.print(); x.print(); }
    }
    private int house_number;
    private String street;
    private int apartment_number;
    private String city;
    private String country;
    private int postal_code;


}

class x{

    public static void main(String[] args)
    {
            Address ad1= new Address();
            System.out.println("My adress ");
            ad1.print();

            Address ad2 = new Address(5);
            System.out.println("Your adress ");
            ad2.print();

            ad2.get_house(41);
            ad2.get_code(1212);
            ad2.get_street("chan_miya_road");

            Address ad3= new Address();
            ad3.compareTo(ad1,ad2);


    }


}
